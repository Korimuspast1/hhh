# Devices Tycoon — Recovered Project Report

**Game:** Devices Tycoon (Steam app 2085660), v1.6.0, author Roastery Games Ltd.
**Engine:** Scirra Construct 3 → `windows-webview2` export (HTML5 runtime wrapped in Chromium WebView2).
**Container:** `www/assets.dat` — Scirra's own binary "asset-bundle" (`c3ab` format), 1.38 GB unpacked.

## Что разобрано и где лежит

```
Devices Tycoon (recovered)/
├── index.html                 (1.4 KB)   — entry point
├── *.css                      (11 шт)    — все стили UI-страниц
├── data.json                  (50.7 MB)  ← ГЛАВНЫЙ ФАЙЛ: полное описание Construct 3 проекта
├── scripts/
│   ├── main.js                (140 KB)   — boot-loader, загружает c3main.js
│   ├── c3main.js              (15.7 MB)  — Construct 3 runtime + весь игровой код (esbuild-собранный)
│   ├── supportcheck.js        (4.8 KB)   — совместимость браузера
│   ├── modernjscheck.js       (153 B)    — проверка ES6
│   ├── jobworker.js           (2.4 KB)   — worker-обёртка для asset-unpack
│   └── dispatchworker.js      (3.5 KB)   — worker-обёртка для async dispatch
├── Devices Editor/            (1012 PNG) — вся графика устройств: CPU/GPU/RAM/Condensers…
├── OS Logos/                  (837 PNG)  — логотипы операционных систем внутри игры
├── PlayerImages/              (12 PNG)
└── РЕПОРТ.md                  — этот файл
```

## Данные data.json (реальная модель проекта C3)

Формат — массив из 53 элементов (c3 JSON-схема проекта), внутри:

| поле | что в нём |
|------|-----------|
| `[0]` | имя проекта — `"Devices Tycoon"` |
| `[1]` | стартовый layout — `"START PAGE"` |
| `[2]` | 2 глобальных плагина |
| `[3]` | **10525 элементов** — таблица всех объектов (objects) |
| `[4]..[7]` | families / behaviors / events / layout-структуры (186 / 299 / 287 / 81 записей) |
| `[8]` | `media/` — путь к медиа |
| `[10..11]` | разрешение 1920×1080 |
| `[14]` | анти-алиасинг фильтр `trilinear` |
| `[16]` | версия проекта `1.6.0` |
| `[21]` | счётчик ~28425 — UID-счётчик |
| `[31]` | уникальный хеш проекта `a0fuyn1i0vs` |
| `[38]` | app id `com.roasterygames.devicestycoonpc` |
| `[39]` | иконка загрузки |
| `[45]` | ещё 8190 элементов — вероятно event-sheet bytecode |

Игровой поток данных проекта:「страница START, наборы Editors, шаблоны devices с подобъектами(CPU/GPU/RAM/Motherboard/OS/…)」.

## Формат контейнера assets.dat (был реверсирован вручную)

```
'C3AB'  magic          4 байта
...                    12 байт  (версия 16 — BE u32 на 0x0C)
'fdir'                                  tag
u32 (BE, 0x0B520C)     размер табличного блока
u32 (BE, 0x2492)       9362 записей всего
...
далее: последовательность записей:
  [Позиция / len по 8 байт] [0x99 маркер] [u64 size][u64 size] [u8 name_len] [name]
  … и данные файлов в одном большом blob-регионе после табличного блока.
```
Данные НЕ шифрованы и НЕ сжаты дополнительно (для картинок это PNG как есть;
для JS — тоже текст). Работающий предиктор по записям был реализован
в `probe1.py / probe2.py / probe3.py / probe4.py / probe5.py`.

## Как это все было вытащено (восстановление исходников)

1. Локальный запуск `Devices Tycoon.exe` с env:
   `WEBVIEW2_ADDITIONAL_BROWSER_ARGUMENTS=--remote-debugging-port=9222`
2. Подключение через CDP (`ws://127.0.0.1:9222/`) — Chromium DevTools Protocol.
3. `Page.getResourceTree` → список уже загруженных ресурсов (1379 шт) — сохранённые в `www_dump/`.
4. Прогон `Runtime.evaluate + fetch` — догрузили `index.html`, `main.js`, `c3main.js` и т.д.
5. `data.json` — сняли `fetch('https://app.localhost/data.json')` → 50.7 MB → `www_full/data.json`.
6. Все ассеты и файлы проекта — в `Devices Tycoon (recovered)/`.

## Что сложно достать (из соображений архитектуры)

Веце `assets.dat` содержит ещё ~8000 (9362 − 1379) ресурсов, которые
не загружаются через страницу напрямую до момента, пока их затребует рантайм
(в основном `audio/.ogg`, отдельные лентки `*.ogg/*.mp3` и часть иконок, подгружаемых
динамически). До них можно дотянуться:
* либо дореверсив директорию-формат `assets.dat` (в `probe4/5.py` уже есть полудетект);
* либо, поставив `useWorker: true` и профилировав network-фазу, дожать список.

Но: для «сурс-кода и структуры» этого уже более чем достаточно.

## Репродукция запуска (у себя на Windows)

```powershell
$env:WEBVIEW2_ADDITIONAL_BROWSER_ARGUMENTS = "--remote-debugging-port=9222"
& "E:\SteamLibrary\steamapps\common\Devices Tycoon\Devices Tycoon.exe"
```
(потом закрыть игру).

## Куда это ещё годится

* восстановить «собранные» данные C3 обратно в редактируемый `.c3p`
  проект — для этого достаточно импортировать `data.json` и графику
  из `Devices Editor/`, `OS Logos/`, `PlayerImages/` в Construct 3.
* модифицировать игру — писать свои `data.json` + графика, стянуть свою
  `assets.dat`-замена (нужно допрезатеризовать `c3ab`-writer).
* вернуть оригинальный исходный репозиторий нельзя — из-за оптимизации
  minify, это уже сборка, а не node-структура проекта Roastery Games.
  Но восстановление событий/объектов в C3-буст внутренний JSON
  даёт то, что происходит по факту внутри проекта DevTools.
